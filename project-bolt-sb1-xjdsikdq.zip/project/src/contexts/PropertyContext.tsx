import React, { createContext, useContext, useState, useEffect } from 'react';

interface Property {
  id: number;
  title: string;
  description: string;
  price: number;
  location: string;
  type: string;
  status: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  year_built?: number;
  amenities?: string[];
  images?: string[];
}

interface PropertyContextType {
  properties: Property[];
  loading: boolean;
  addProperty: (property: Omit<Property, 'id'>) => void;
  updateProperty: (id: number, property: Partial<Property>) => void;
  deleteProperty: (id: number) => void;
}

const PropertyContext = createContext<PropertyContextType | undefined>(undefined);

export const useProperty = () => {
  const context = useContext(PropertyContext);
  if (!context) {
    throw new Error('useProperty must be used within a PropertyProvider');
  }
  return context;
};

export const PropertyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);

  // Initialize with sample data
  useEffect(() => {
    const sampleProperties: Property[] = [
      {
        id: 1,
        title: 'Luxury Villa in Bandra',
        description: 'A stunning 4-bedroom luxury villa with modern amenities, spacious living areas, and a private garden. Perfect for families looking for comfort and elegance.',
        price: 12000000,
        location: 'Bandra West, Mumbai',
        type: 'villa',
        status: 'for_sale',
        bedrooms: 4,
        bathrooms: 3,
        area: 3500,
        year_built: 2018,
        amenities: ['Parking', 'Swimming Pool', 'Security', 'Garden', 'Air Conditioning'],
        images: ['https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800']
      },
      {
        id: 2,
        title: 'Modern Apartment',
        description: 'Contemporary 3-bedroom apartment with city views, premium finishes, and access to world-class amenities in a prime location.',
        price: 8500000,
        location: 'Andheri East, Mumbai',
        type: 'apartment',
        status: 'for_sale',
        bedrooms: 3,
        bathrooms: 2,
        area: 1800,
        year_built: 2020,
        amenities: ['Parking', 'Gym', 'Security', 'Elevator', 'Air Conditioning'],
        images: ['https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=800']
      },
      {
        id: 3,
        title: 'Penthouse Suite',
        description: 'Exclusive penthouse with panoramic views, private terrace, and premium amenities. The epitome of luxury living in the heart of the city.',
        price: 25000000,
        location: 'Worli, Mumbai',
        type: 'apartment',
        status: 'for_sale',
        bedrooms: 5,
        bathrooms: 4,
        area: 4200,
        year_built: 2019,
        amenities: ['Parking', 'Swimming Pool', 'Gym', 'Security', 'Garden', 'Club House'],
        images: ['https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=800']
      },
      {
        id: 4,
        title: 'Commercial Office Space',
        description: 'Prime commercial office space with modern infrastructure, ample parking, and excellent connectivity. Ideal for businesses looking to establish a presence in Mumbai.',
        price: 15000000,
        location: 'BKC, Mumbai',
        type: 'office',
        status: 'for_rent',
        bedrooms: 0,
        bathrooms: 2,
        area: 2500,
        year_built: 2021,
        amenities: ['Parking', 'Security', 'Elevator', 'Power Backup', 'Internet'],
        images: ['https://images.pexels.com/photos/380768/pexels-photo-380768.jpeg?auto=compress&cs=tinysrgb&w=800']
      },
      {
        id: 5,
        title: 'Family House',
        description: 'Spacious family house with traditional architecture and modern amenities. Features a large garden and is located in a quiet residential area.',
        price: 9500000,
        location: 'Juhu, Mumbai',
        type: 'house',
        status: 'for_sale',
        bedrooms: 4,
        bathrooms: 3,
        area: 2800,
        year_built: 2017,
        amenities: ['Parking', 'Garden', 'Security', 'Air Conditioning', 'Water Supply'],
        images: ['https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800']
      },
      {
        id: 6,
        title: 'Studio Apartment',
        description: 'Compact and efficient studio apartment perfect for young professionals. Modern design with all essential amenities in a prime location.',
        price: 4500000,
        location: 'Powai, Mumbai',
        type: 'apartment',
        status: 'for_sale',
        bedrooms: 1,
        bathrooms: 1,
        area: 650,
        year_built: 2022,
        amenities: ['Parking', 'Security', 'Elevator', 'Gym', 'CCTV'],
        images: ['https://images.pexels.com/photos/1571468/pexels-photo-1571468.jpeg?auto=compress&cs=tinysrgb&w=800']
      }
    ];

    setProperties(sampleProperties);
    setLoading(false);
  }, []);

  const addProperty = (propertyData: Omit<Property, 'id'>) => {
    const newProperty: Property = {
      ...propertyData,
      id: Date.now(), // Simple ID generation
    };
    setProperties(prev => [newProperty, ...prev]);
  };

  const updateProperty = (id: number, updates: Partial<Property>) => {
    setProperties(prev => 
      prev.map(property => 
        property.id === id ? { ...property, ...updates } : property
      )
    );
  };

  const deleteProperty = (id: number) => {
    setProperties(prev => prev.filter(property => property.id !== id));
  };

  return (
    <PropertyContext.Provider value={{
      properties,
      loading,
      addProperty,
      updateProperty,
      deleteProperty
    }}>
      {children}
    </PropertyContext.Provider>
  );
};