import React from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, TrendingUp, Users, Star, Phone, Mail, Award } from 'lucide-react';

const Homepage = () => {
  const stats = [
    { icon: <Users className="w-8 h-8" />, value: '500+', label: 'Happy Clients' },
    { icon: <TrendingUp className="w-8 h-8" />, value: '1000+', label: 'Properties Sold' },
    { icon: <Award className="w-8 h-8" />, value: '15+', label: 'Years Experience' },
    { icon: <Star className="w-8 h-8" />, value: '4.9', label: 'Client Rating' },
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      role: 'Home Buyer',
      content: 'Rohan helped us find our dream home. His expertise and dedication made the process seamless.',
      rating: 5
    },
    {
      name: 'Amit Patel',
      role: 'Property Investor',
      content: 'Excellent service and market knowledge. Silfira Realtors exceeded our expectations.',
      rating: 5
    },
    {
      name: 'Sunita Mehta',
      role: 'Property Seller',
      content: 'Professional approach and quick sale. Highly recommend for anyone looking to sell property.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-green-900 via-green-800 to-green-700 text-white py-24 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-30"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                Find Your
                <span className="block text-yellow-300">Dream Home</span>
              </h1>
              <p className="text-xl mb-8 text-green-100 leading-relaxed">
                Discover luxury properties with Silfira Realtors. Expert guidance, premium locations, and exceptional service for discerning clients.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/properties"
                  className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-4 px-8 rounded-lg transition-all transform hover:scale-105 text-center"
                >
                  Explore Properties
                </Link>
                <Link
                  to="/contact"
                  className="border-2 border-white text-white hover:bg-white hover:text-green-800 font-semibold py-4 px-8 rounded-lg transition-all text-center"
                >
                  Get Consultation
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20">
                <h3 className="text-2xl font-semibold mb-6">Quick Property Search</h3>
                <div className="space-y-4">
                  <div>
                    <input
                      type="text"
                      placeholder="Location"
                      className="w-full p-3 rounded-lg bg-white/20 border border-white/30 text-white placeholder-white/70 focus:outline-none focus:border-yellow-300"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <select className="p-3 rounded-lg bg-white/20 border border-white/30 text-white focus:outline-none focus:border-yellow-300">
                      <option value="">Property Type</option>
                      <option value="apartment">Apartment</option>
                      <option value="villa">Villa</option>
                      <option value="office">Office</option>
                    </select>
                    <select className="p-3 rounded-lg bg-white/20 border border-white/30 text-white focus:outline-none focus:border-yellow-300">
                      <option value="">Budget Range</option>
                      <option value="0-50">Under ₹50L</option>
                      <option value="50-100">₹50L - ₹1Cr</option>
                      <option value="100+">Above ₹1Cr</option>
                    </select>
                  </div>
                  <button className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-3 px-6 rounded-lg transition-colors flex items-center justify-center gap-2">
                    <Search className="w-5 h-5" />
                    Search Properties
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4 text-green-700">
                  {stat.icon}
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Agent Showcase */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Meet Your Expert Agent</h2>
              <div className="bg-gradient-to-br from-green-50 to-yellow-50 p-8 rounded-2xl">
                <div className="flex items-center mb-6">
                  <div className="w-20 h-20 bg-green-700 rounded-full flex items-center justify-center text-white text-2xl font-bold mr-6">
                    RD
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">Rohan Darji</h3>
                    <p className="text-green-700 font-medium">Founder & Principal Agent</p>
                    <div className="flex items-center mt-2">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 text-yellow-500 fill-current" />
                      ))}
                      <span className="ml-2 text-sm text-gray-600">4.9/5 Rating</span>
                    </div>
                  </div>
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  With over 15 years in luxury real estate, Rohan specializes in premium properties and exceptional client service. His deep market knowledge and personalized approach have helped hundreds of clients find their perfect homes.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <a
                    href="tel:+919876543210"
                    className="flex items-center justify-center gap-2 bg-green-700 text-white py-3 px-6 rounded-lg hover:bg-green-800 transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    Call Now
                  </a>
                  <a
                    href="mailto:rohan@silfirarealtors.com"
                    className="flex items-center justify-center gap-2 border border-green-700 text-green-700 py-3 px-6 rounded-lg hover:bg-green-50 transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    Email
                  </a>
                </div>
              </div>
            </div>
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-700">
                <h4 className="font-semibold text-gray-900 mb-2">Expert Market Analysis</h4>
                <p className="text-gray-600">Get accurate property valuations and market insights for informed decisions.</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-yellow-500">
                <h4 className="font-semibold text-gray-900 mb-2">Personalized Service</h4>
                <p className="text-gray-600">Tailored solutions matching your unique requirements and preferences.</p>
              </div>
              <div className="bg-white p-6 rounded-xl shadow-lg border-l-4 border-green-700">
                <h4 className="font-semibold text-gray-900 mb-2">End-to-End Support</h4>
                <p className="text-gray-600">Complete assistance from property search to final documentation.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties Preview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Properties</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover our handpicked selection of premium properties in prime locations
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="h-64 bg-gradient-to-br from-green-200 to-green-300"></div>
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-medium">
                      For Sale
                    </span>
                    <span className="text-2xl font-bold text-gray-900">₹1.2 Cr</span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Luxury Villa</h3>
                  <div className="flex items-center text-gray-600 mb-4">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>Bandra West, Mumbai</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600 mb-4">
                    <span>3 Bedrooms</span>
                    <span>2 Bathrooms</span>
                    <span>2500 sq ft</span>
                  </div>
                  <button className="w-full bg-green-700 text-white py-3 rounded-lg hover:bg-green-800 transition-colors">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center">
            <Link
              to="/properties"
              className="bg-green-700 text-white py-4 px-8 rounded-lg hover:bg-green-800 transition-colors font-semibold"
            >
              View All Properties
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Client Testimonials</h2>
            <p className="text-xl text-gray-600">What our satisfied clients say about us</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-xl">
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-500 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 leading-relaxed">"{testimonial.content}"</p>
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-green-700 text-sm">{testimonial.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-green-700 to-green-800 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Find Your Dream Property?</h2>
          <p className="text-xl mb-8 text-green-100">
            Get in touch with us today for personalized assistance and expert guidance
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-yellow-500 hover:bg-yellow-600 text-black font-semibold py-4 px-8 rounded-lg transition-all transform hover:scale-105"
            >
              Contact Us Today
            </Link>
            <Link
              to="/properties"
              className="border-2 border-white text-white hover:bg-white hover:text-green-800 font-semibold py-4 px-8 rounded-lg transition-all"
            >
              Browse Properties
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Homepage;