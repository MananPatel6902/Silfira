import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MapPin, Bed, Bath, Square, Calendar, Phone, Mail, Heart, Share2, ArrowLeft } from 'lucide-react';
import { useProperty } from '../contexts/PropertyContext';

const PropertyDetails = () => {
  const { id } = useParams();
  const { properties } = useProperty();
  const [property, setProperty] = useState(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [showContactForm, setShowContactForm] = useState(false);

  useEffect(() => {
    const foundProperty = properties.find(p => p.id === parseInt(id));
    setProperty(foundProperty);
  }, [id, properties]);

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Property not found</h2>
          <Link to="/properties" className="text-green-700 hover:text-green-800">
            ← Back to Properties
          </Link>
        </div>
      </div>
    );
  }

  const formatPrice = (price) => {
    if (price >= 10000000) {
      return `₹${(price / 10000000).toFixed(1)} Cr`;
    } else if (price >= 100000) {
      return `₹${(price / 100000).toFixed(0)} L`;
    }
    return `₹${price.toLocaleString()}`;
  };

  const images = property.images || ['https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=800'];

  return (
    <div className="min-h-screen bg-white">
      {/* Back Navigation */}
      <div className="bg-gray-50 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            to="/properties"
            className="flex items-center text-green-700 hover:text-green-800 transition-colors"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Properties
          </Link>
        </div>
      </div>

      {/* Image Gallery */}
      <div className="relative">
        <div className="h-96 lg:h-[500px] overflow-hidden">
          <img
            src={images[currentImageIndex]}
            alt={property.title}
            className="w-full h-full object-cover"
          />
        </div>
        
        {images.length > 1 && (
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {images.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`w-3 h-3 rounded-full ${
                  index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        )}
        
        <div className="absolute top-4 right-4 flex space-x-2">
          <button className="bg-white/90 p-3 rounded-full hover:bg-white transition-colors">
            <Heart className="w-5 h-5 text-gray-700" />
          </button>
          <button className="bg-white/90 p-3 rounded-full hover:bg-white transition-colors">
            <Share2 className="w-5 h-5 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Property Details */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                  property.status === 'for_sale' 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-blue-100 text-blue-700'
                }`}>
                  {property.status === 'for_sale' ? 'For Sale' : 'For Rent'}
                </span>
                <span className="text-3xl font-bold text-gray-900">
                  {formatPrice(property.price)}
                </span>
              </div>
              
              <h1 className="text-3xl font-bold text-gray-900 mb-4">{property.title}</h1>
              
              <div className="flex items-center text-gray-600 mb-6">
                <MapPin className="w-5 h-5 mr-2" />
                <span className="text-lg">{property.location}</span>
              </div>
            </div>

            {/* Property Features */}
            <div className="grid grid-cols-4 gap-6 mb-8 p-6 bg-gray-50 rounded-xl">
              <div className="text-center">
                <Bed className="w-8 h-8 mx-auto mb-2 text-green-700" />
                <div className="text-2xl font-semibold text-gray-900">{property.bedrooms}</div>
                <div className="text-sm text-gray-600">Bedrooms</div>
              </div>
              <div className="text-center">
                <Bath className="w-8 h-8 mx-auto mb-2 text-green-700" />
                <div className="text-2xl font-semibold text-gray-900">{property.bathrooms}</div>
                <div className="text-sm text-gray-600">Bathrooms</div>
              </div>
              <div className="text-center">
                <Square className="w-8 h-8 mx-auto mb-2 text-green-700" />
                <div className="text-2xl font-semibold text-gray-900">{property.area}</div>
                <div className="text-sm text-gray-600">Sq Ft</div>
              </div>
              <div className="text-center">
                <Calendar className="w-8 h-8 mx-auto mb-2 text-green-700" />
                <div className="text-2xl font-semibold text-gray-900">{property.year_built || 'N/A'}</div>
                <div className="text-sm text-gray-600">Year Built</div>
              </div>
            </div>

            {/* Description */}
            <div className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Description</h2>
              <p className="text-gray-700 leading-relaxed">{property.description}</p>
            </div>

            {/* Amenities */}
            {property.amenities && property.amenities.length > 0 && (
              <div className="mb-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {property.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center p-3 bg-green-50 rounded-lg">
                      <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                      <span className="text-gray-700">{amenity}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Agent Contact Card */}
            <div className="bg-gray-50 p-6 rounded-xl mb-6 sticky top-8">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-green-700 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-4">
                  RD
                </div>
                <h3 className="text-xl font-semibold text-gray-900">Rohan Darji</h3>
                <p className="text-green-700">Principal Agent</p>
              </div>
              
              <div className="space-y-4 mb-6">
                <a
                  href="tel:+919876543210"
                  className="w-full bg-green-700 text-white py-3 px-4 rounded-lg hover:bg-green-800 transition-colors flex items-center justify-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  Call Now
                </a>
                <a
                  href="mailto:rohan@silfirarealtors.com"
                  className="w-full border border-green-700 text-green-700 py-3 px-4 rounded-lg hover:bg-green-50 transition-colors flex items-center justify-center gap-2"
                >
                  <Mail className="w-4 h-4" />
                  Email
                </a>
              </div>

              <button
                onClick={() => setShowContactForm(!showContactForm)}
                className="w-full bg-yellow-500 text-black py-3 px-4 rounded-lg hover:bg-yellow-600 transition-colors font-medium"
              >
                Request Info
              </button>

              {showContactForm && (
                <div className="mt-6 p-4 border-t border-gray-200">
                  <form className="space-y-4">
                    <input
                      type="text"
                      placeholder="Your Name"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <input
                      type="email"
                      placeholder="Your Email"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <input
                      type="tel"
                      placeholder="Your Phone"
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    />
                    <textarea
                      placeholder="Your Message"
                      rows={3}
                      className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    ></textarea>
                    <button
                      type="submit"
                      className="w-full bg-green-700 text-white py-3 rounded-lg hover:bg-green-800 transition-colors"
                    >
                      Send Message
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyDetails;